# Barbearia Pro — Android — Etapa 5

Nesta etapa o projeto acrescenta gestão avançada e segurança dos dados locais.

## Incluído
- Editar e eliminar clientes.
- Pesquisar clientes por nome/telefone.
- Eliminar vendas.
- Editar/desativar serviços.
- Editar/desativar barbeiros.
- Eliminar despesas.
- Pesquisa no histórico de vendas.
- Backup completo em JSON e partilha/guarda através do Android.
- Restauro de backup colando o JSON guardado.
- Definições: nome e telefone da barbearia.
- Nome configurado aparece no cabeçalho e no recibo.

## Versão
1.2.0

## Importante
Esta é a etapa do projeto Android, ainda não é o APK final. Para gerar o APK é necessário abrir o projeto no Android Studio e fazer o build.
