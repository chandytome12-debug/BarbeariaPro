# Barbearia Pro — Android — Etapa 6

Versão: 1.3.0

## O que foi acrescentado
- PIN de administrador de 4 a 6 dígitos, guardado localmente no Android.
- Bloqueio manual da aplicação.
- Definir, alterar ou remover PIN em Gestão > Backup > Definições.
- Dashboard financeiro com lucro do dia e ticket médio.
- Cabeçalho e interface mais profissionais e responsivos.
- Área de definições preparada para personalização da barbearia.
- Mantém a base SQLite, vendas, clientes, serviços, barbeiros, despesas, relatórios, recibos e backup das etapas anteriores.

## Primeiro acesso
1. Abrir o projeto no Android Studio.
2. Executar a aplicação no telefone/emulador.
3. Na primeira abertura, criar um PIN de 4 a 6 dígitos.
4. O PIN é armazenado localmente no aparelho.

## Próxima etapa
Etapa 7: preparação final de produção, ícone/nome da aplicação, permissões, assinatura e geração do APK instalável.
