# Barbearia Pro — Etapa 7 (1.4.0)

Etapa de preparação para produção do aplicativo Android.

## Incluído
- Ícone da aplicação configurado.
- Nome da aplicação: Barbearia Pro.
- Application ID: `ao.barbeariapro.app`.
- VersionCode: 3.
- VersionName: 1.4.0.
- Manifest preparado para instalação normal no Android.
- Base offline preservada: SQLite + WebView local.
- Sem dependência de servidor web para o funcionamento da aplicação.

## Como gerar o APK no Android Studio
1. Instale o Android Studio num computador.
2. Extraia este ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `BarbeariaPro_Android_Etapa6`.
4. Aguarde a sincronização do Gradle.
5. Use **Build > Build APK(s)** para gerar um APK de teste.
6. O APK normalmente ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## APK de distribuição
Para publicar ou distribuir uma versão oficial, use **Build > Generate Signed App Bundle / APK** e crie/seleccione uma chave de assinatura. A chave deve ser guardada com segurança; ela não é incluída neste projeto.

## Nota
Esta etapa prepara o projeto para compilação. O APK binário não é gerado automaticamente neste ambiente porque não há um Android SDK/Gradle completo configurado aqui.
