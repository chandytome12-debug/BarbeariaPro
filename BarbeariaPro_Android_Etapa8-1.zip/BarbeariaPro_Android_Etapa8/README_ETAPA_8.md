# Barbearia Pro — Etapa 8

## Gerar o APK sem computador

Esta versão adiciona um workflow do GitHub Actions para compilar o APK na nuvem. O projeto não precisa de Android Studio no telemóvel.

### 1. Criar conta no GitHub
No Samsung, abra o GitHub e crie uma conta, caso ainda não tenha.

### 2. Criar um repositório
Crie um repositório novo, por exemplo:
`barbearia-pro`

Pode deixar o repositório **Private**.

### 3. Enviar este projeto
No repositório, use **Add file → Upload files** e envie o conteúdo desta pasta ZIP, mantendo a estrutura:
- `.github/workflows/build-apk.yml`
- `app/`
- `build.gradle.kts`
- `settings.gradle.kts`
- `gradle.properties`

Não envie a pasta Etapa8 inteira como uma pasta dentro do repositório. O `build.gradle.kts` deve ficar na raiz.

### 4. Iniciar a compilação
Abra **Actions** → **Gerar APK - Barbearia Pro** → **Run workflow** → escolha `main` → **Run workflow**.

O workflow instala Java, Gradle e Android SDK e executa `gradle :app:assembleDebug`.

### 5. Baixar o APK
Quando aparecer um visto verde:
- abra a execução concluída;
- desça até **Artifacts**;
- toque em **BarbeariaPro-APK**;
- descarregue o ZIP do artefacto;
- extraia-o no telemóvel;
- encontrará `app-debug.apk`.

### 6. Instalar no Samsung A14
Abra `app-debug.apk` e permita a instalação de aplicações desta origem quando o Android pedir.

## Observação
Esta Etapa 8 gera um APK **Debug** para testes. A próxima etapa pode preparar uma versão **Release assinada**, adequada para distribuição. Não partilhe nem perca a chave de assinatura quando ela for criada.
