package ao.barbeariapro.app

import android.content.Context
import android.content.Intent
import android.webkit.JavascriptInterface
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BarbeariaBridge(private val db: DatabaseHelper, private val context: Context) {
    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    @JavascriptInterface fun clientes(): String = db.clientes().toString()
    @JavascriptInterface fun servicos(): String = db.servicos().toString()
    @JavascriptInterface fun barbeiros(): String = db.barbeiros().toString()
    @JavascriptInterface fun despesas(): String = db.despesas().toString()
    @JavascriptInterface fun dashboard(): String = db.dashboard(today()).toString()
    @JavascriptInterface fun vendas(): String = db.vendas().toString()
    @JavascriptInterface fun relatorio(inicio:String, fim:String): String = db.relatorio(inicio, fim).toString()
    @JavascriptInterface fun venda(id:String): String = db.venda(id.toIntOrNull() ?: 0).toString()
    @JavascriptInterface fun addCliente(nome:String, telefone:String): String = JSONObject().put("id",db.addCliente(nome.trim(),telefone.trim())).toString()
    @JavascriptInterface fun updateCliente(id:String,nome:String,telefone:String): String = JSONObject().put("ok",db.updateCliente(id.toIntOrNull()?:0,nome.trim(),telefone.trim())>0).toString()
    @JavascriptInterface fun deleteCliente(id:String): String = try { JSONObject().put("ok",db.deleteCliente(id.toIntOrNull()?:0)>0).toString() } catch(e:Exception){ JSONObject().put("ok",false).put("erro","Não é possível eliminar um cliente que já possui vendas.").toString() }
    @JavascriptInterface fun addBarbeiro(nome:String, telefone:String): String = JSONObject().put("id",db.addBarbeiro(nome.trim(),telefone.trim())).toString()
    @JavascriptInterface fun updateBarbeiro(id:String,nome:String,telefone:String): String = JSONObject().put("ok",db.updateBarbeiro(id.toIntOrNull()?:0,nome.trim(),telefone.trim())>0).toString()
    @JavascriptInterface fun deleteBarbeiro(id:String): String = JSONObject().put("ok",db.deleteBarbeiro(id.toIntOrNull()?:0)>0).toString()
    @JavascriptInterface fun addServico(nome:String, preco:String): String = JSONObject().put("id",db.addServico(nome.trim(),preco.toDoubleOrNull()?:0.0)).toString()
    @JavascriptInterface fun updateServico(id:String,nome:String,preco:String): String = JSONObject().put("ok",db.updateServico(id.toIntOrNull()?:0,nome.trim(),preco.toDoubleOrNull()?:0.0)>0).toString()
    @JavascriptInterface fun deleteServico(id:String): String = JSONObject().put("ok",db.deleteServico(id.toIntOrNull()?:0)>0).toString()
    @JavascriptInterface fun addDespesa(descricao:String, valor:String): String = JSONObject().put("id",db.addDespesa(descricao.trim(),valor.toDoubleOrNull()?:0.0,today())).toString()
    @JavascriptInterface fun deleteDespesa(id:String): String = JSONObject().put("ok",db.deleteDespesa(id.toIntOrNull()?:0)>0).toString()
    @JavascriptInterface fun addVenda(clienteId:String, servicoId:String, barbeiro:String, pagamento:String, valor:String, desconto:String, observacao:String): String { val id=db.addVenda(clienteId.toIntOrNull()?:0,servicoId.toIntOrNull()?:0,barbeiro,pagamento,valor.toDoubleOrNull()?:0.0,desconto.toDoubleOrNull()?:0.0,observacao,today()); return JSONObject().put("id",id).toString() }
    @JavascriptInterface fun deleteVenda(id:String): String = JSONObject().put("ok",db.deleteVenda(id.toIntOrNull()?:0)>0).toString()
    @JavascriptInterface fun exportBackup(): String = db.exportBackup().toString()
    @JavascriptInterface fun importBackup(json:String): String = try { JSONObject().put("ok",db.importBackup(json)).toString() } catch(e:Exception) { JSONObject().put("ok",false).put("erro",e.message ?: "Backup inválido").toString() }
    @JavascriptInterface fun shareBackup(json:String) { val i=Intent(Intent.ACTION_SEND); i.type="application/json"; i.putExtra(Intent.EXTRA_TEXT,json); context.startActivity(Intent.createChooser(i,"Guardar/partilhar backup")) }
}
