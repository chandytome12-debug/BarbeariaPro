package ao.barbeariapro.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "barbearia.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE clientes(id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, telefone TEXT)")
        db.execSQL("CREATE TABLE servicos(id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, preco REAL NOT NULL, ativo INTEGER NOT NULL DEFAULT 1)")
        db.execSQL("CREATE TABLE barbeiros(id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, telefone TEXT, ativo INTEGER NOT NULL DEFAULT 1)")
        db.execSQL("CREATE TABLE vendas(id INTEGER PRIMARY KEY AUTOINCREMENT, cliente_id INTEGER, servico_id INTEGER NOT NULL, barbeiro TEXT, pagamento TEXT NOT NULL, valor REAL NOT NULL, desconto REAL NOT NULL DEFAULT 0, observacao TEXT, data TEXT NOT NULL)")
        db.execSQL("CREATE TABLE despesas(id INTEGER PRIMARY KEY AUTOINCREMENT, descricao TEXT NOT NULL, valor REAL NOT NULL, data TEXT NOT NULL)")
        val defaults = listOf("Corte" to 3000.0, "Barba" to 2000.0, "Corte + Barba" to 4500.0)
        defaults.forEach { (nome, preco) ->
            val v = ContentValues().apply { put("nome", nome); put("preco", preco); put("ativo", 1) }
            db.insert("servicos", null, v)
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun exportBackup(): JSONObject {
        val root=JSONObject(); root.put("versao",1); root.put("clientes",clientes()); root.put("servicos",queryArray("SELECT id,nome,preco,ativo FROM servicos")); root.put("barbeiros",queryArray("SELECT id,nome,telefone,ativo FROM barbeiros")); root.put("vendas",queryArray("SELECT id,cliente_id,servico_id,barbeiro,pagamento,valor,desconto,observacao,data FROM vendas")); root.put("despesas",despesas()); return root
    }

    fun importBackup(json:String): Boolean {
        val root=JSONObject(json); val db=writableDatabase; db.beginTransaction()
        try { db.delete("vendas",null,null); db.delete("despesas",null,null); db.delete("clientes",null,null); db.delete("servicos",null,null); db.delete("barbeiros",null,null)
            fun putRows(key:String, table:String, cols:Array<String>) { val a=root.optJSONArray(key)?:JSONArray(); for(i in 0 until a.length()){ val o=a.getJSONObject(i); val v=ContentValues(); cols.forEach{ c -> if(o.has(c)&&!o.isNull(c)) v.put(c,o.getString(c)) }; db.insert(table,null,v) } }
            putRows("clientes","clientes",arrayOf("id","nome","telefone")); putRows("servicos","servicos",arrayOf("id","nome","preco","ativo")); putRows("barbeiros","barbeiros",arrayOf("id","nome","telefone","ativo")); putRows("vendas","vendas",arrayOf("id","cliente_id","servico_id","barbeiro","pagamento","valor","desconto","observacao","data")); putRows("despesas","despesas",arrayOf("id","descricao","valor","data")); db.setTransactionSuccessful(); return true
        } finally { db.endTransaction() }
    }


    fun vendas(): JSONArray = queryArray("SELECT v.id, v.data, COALESCE(c.nome,'Cliente balcão') AS cliente, COALESCE(s.nome,'Serviço') AS servico, COALESCE(v.barbeiro,'') AS barbeiro, v.pagamento, v.valor, v.desconto, (v.valor-v.desconto) AS total, COALESCE(v.observacao,'') AS observacao FROM vendas v LEFT JOIN clientes c ON c.id=v.cliente_id LEFT JOIN servicos s ON s.id=v.servico_id ORDER BY v.id DESC")

    fun venda(id: Int): JSONObject {
        val arr = queryArray("SELECT v.id, v.data, COALESCE(c.nome,'Cliente balcão') AS cliente, COALESCE(s.nome,'Serviço') AS servico, COALESCE(v.barbeiro,'') AS barbeiro, v.pagamento, v.valor, v.desconto, (v.valor-v.desconto) AS total, COALESCE(v.observacao,'') AS observacao FROM vendas v LEFT JOIN clientes c ON c.id=v.cliente_id LEFT JOIN servicos s ON s.id=v.servico_id WHERE v.id=?", arrayOf(id.toString()))
        return if (arr.length()>0) arr.getJSONObject(0) else JSONObject()
    }

    fun relatorio(inicio: String, fim: String): JSONObject {
        val db=readableDatabase; val o=JSONObject()
        o.put("faturacao", scalar(db,"SELECT COALESCE(SUM(valor-desconto),0) FROM vendas WHERE date(data) BETWEEN date(?) AND date(?)", arrayOf(inicio,fim)))
        o.put("vendas", scalar(db,"SELECT COUNT(*) FROM vendas WHERE date(data) BETWEEN date(?) AND date(?)", arrayOf(inicio,fim)))
        o.put("despesas", scalar(db,"SELECT COALESCE(SUM(valor),0) FROM despesas WHERE date(data) BETWEEN date(?) AND date(?)", arrayOf(inicio,fim)))
        o.put("lucro", o.getDouble("faturacao")-o.getDouble("despesas"))
        o.put("porPagamento", queryArray("SELECT pagamento, COUNT(*) AS quantidade, COALESCE(SUM(valor-desconto),0) AS total FROM vendas WHERE date(data) BETWEEN date(?) AND date(?) GROUP BY pagamento ORDER BY total DESC", arrayOf(inicio,fim)))
        o.put("porServico", queryArray("SELECT COALESCE(s.nome,'Serviço') AS servico, COUNT(*) AS quantidade, COALESCE(SUM(v.valor-v.desconto),0) AS total FROM vendas v LEFT JOIN servicos s ON s.id=v.servico_id WHERE date(v.data) BETWEEN date(?) AND date(?) GROUP BY s.nome ORDER BY total DESC", arrayOf(inicio,fim)))
        return o
    }

    fun clientes(): JSONArray = queryArray("SELECT id,nome,telefone FROM clientes ORDER BY nome")

    fun updateCliente(id:Int,nome:String,telefone:String): Int = writableDatabase.update("clientes", ContentValues().apply { put("nome",nome); put("telefone",telefone) }, "id=?", arrayOf(id.toString()))
    fun deleteCliente(id:Int): Int = writableDatabase.delete("clientes","id=?",arrayOf(id.toString()))
    fun updateServico(id:Int,nome:String,preco:Double): Int = writableDatabase.update("servicos", ContentValues().apply { put("nome",nome); put("preco",preco) }, "id=?", arrayOf(id.toString()))
    fun deleteServico(id:Int): Int = writableDatabase.update("servicos", ContentValues().apply { put("ativo",0) }, "id=?", arrayOf(id.toString()))
    fun updateBarbeiro(id:Int,nome:String,telefone:String): Int = writableDatabase.update("barbeiros", ContentValues().apply { put("nome",nome); put("telefone",telefone) }, "id=?", arrayOf(id.toString()))
    fun deleteBarbeiro(id:Int): Int = writableDatabase.update("barbeiros", ContentValues().apply { put("ativo",0) }, "id=?", arrayOf(id.toString()))
    fun deleteVenda(id:Int): Int = writableDatabase.delete("vendas","id=?",arrayOf(id.toString()))
    fun despesas(): JSONArray = queryArray("SELECT id,descricao,valor,data FROM despesas ORDER BY id DESC")
    fun deleteDespesa(id:Int): Int = writableDatabase.delete("despesas","id=?",arrayOf(id.toString()))
    fun servicos(): JSONArray = queryArray("SELECT id,nome,preco FROM servicos WHERE ativo=1 ORDER BY nome")
    fun barbeiros(): JSONArray = queryArray("SELECT id,nome,telefone FROM barbeiros WHERE ativo=1 ORDER BY nome")

    private fun queryArray(sql: String, args: Array<String>?=null): JSONArray {
        val arr = JSONArray(); readableDatabase.rawQuery(sql, args).use { c ->
            while (c.moveToNext()) { val o=JSONObject(); for(i in 0 until c.columnCount) o.put(c.getColumnName(i), c.getString(i)); arr.put(o) }
        }; return arr
    }

    fun addCliente(nome: String, telefone: String): Int = insert("clientes", ContentValues().apply { put("nome", nome); put("telefone", telefone) })
    fun addBarbeiro(nome: String, telefone: String): Int = insert("barbeiros", ContentValues().apply { put("nome", nome); put("telefone", telefone); put("ativo", 1) })
    fun addServico(nome: String, preco: Double): Int = insert("servicos", ContentValues().apply { put("nome", nome); put("preco", preco); put("ativo", 1) })
    fun addDespesa(descricao: String, valor: Double, data: String): Int = insert("despesas", ContentValues().apply { put("descricao", descricao); put("valor", valor); put("data", data) })

    private fun insert(table: String, values: ContentValues): Int = writableDatabase.insert(table, null, values).toInt()

    fun addVenda(clienteId: Int, servicoId: Int, barbeiro: String, pagamento: String, valor: Double, desconto: Double, observacao: String, data: String): Int =
        insert("vendas", ContentValues().apply { put("cliente_id", if(clienteId>0) clienteId else null as Int?); put("servico_id", servicoId); put("barbeiro", barbeiro); put("pagamento", pagamento); put("valor", valor); put("desconto", desconto); put("observacao", observacao); put("data", data) })

    fun dashboard(data: String): JSONObject {
        val db=readableDatabase; val o=JSONObject()
        o.put("clientes", scalar(db,"SELECT COUNT(*) FROM clientes"))
        o.put("vendas", scalar(db,"SELECT COUNT(*) FROM vendas WHERE date(data)=date(?)", arrayOf(data)))
        o.put("faturacao", scalar(db,"SELECT COALESCE(SUM(valor-desconto),0) FROM vendas WHERE date(data)=date(?)", arrayOf(data)))
        o.put("despesas", scalar(db,"SELECT COALESCE(SUM(valor),0) FROM despesas WHERE date(data)=date(?)", arrayOf(data)))
        return o
    }
    private fun scalar(db: SQLiteDatabase, sql: String, args: Array<String>?=null): Double { db.rawQuery(sql,args).use{c-> if(c.moveToFirst()) return c.getDouble(0)}; return 0.0 }
}
