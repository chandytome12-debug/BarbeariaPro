package ao.barbeariapro.app

import android.content.Context
import android.content.SharedPreferences
import android.webkit.JavascriptInterface
import org.json.JSONObject

class SecurityBridge(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("barbearia_security", Context.MODE_PRIVATE)
    @JavascriptInterface fun hasPin(): Boolean = prefs.contains("pin")
    @JavascriptInterface fun verifyPin(pin: String): Boolean = pin == prefs.getString("pin", null)
    @JavascriptInterface fun setPin(pin: String): String {
        val clean = pin.trim()
        if (!clean.matches(Regex("\\d{4,6}"))) return JSONObject().put("ok", false).put("erro", "O PIN deve ter 4 a 6 dígitos.").toString()
        prefs.edit().putString("pin", clean).apply()
        return JSONObject().put("ok", true).toString()
    }
    @JavascriptInterface fun removePin(pin: String): String {
        if (!verifyPin(pin)) return JSONObject().put("ok", false).put("erro", "PIN atual incorreto.").toString()
        prefs.edit().remove("pin").apply()
        return JSONObject().put("ok", true).toString()
    }
}
